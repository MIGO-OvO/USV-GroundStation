## License

This code is licensed under the [MIT](./LICENSE) license.

## Changelog

[GitHub changelog](https://github.com/OpenByteDev/dlopen2/releases)

## Acknowledgement

Special thanks to [Simonas Kazlauskas](https://github.com/nagisa) whose [libloading](https://github.com/nagisa/rust_libloading) became code base for my project.
